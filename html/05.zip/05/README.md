# blink
http://codepen.io/anon/pen/obxGZd

sorting as original (done)
fixed width responsive (done)
fixed gutter/percentage gutter (done)
follow psd width (done)

DESKTOP
- project page => new page (done)
- follow style guide (done)
- gotham/herriet replacement (no need)
- site search wordpress search?
- portfolio search (no need)
- sorting portfolio item as default (done)
- portfolio show more json
- portfolio projects pages.. - filter remove show more

Mobile
- site search
- insights/portfolio/contact (done)
- careers/profile

Tablet
- ipad font size (done)

.grid-3 {
	margin: 0 auto;			
}

.number {
	// display: none;
}

.grid-sizer-3 {
	width: 200px;
}
.gutter-sizer-3 {
	// width: 0.54%;
	width: 6px;
}
.grid-item-3 { 
	// float: left;
	display: inline-block;
	// width: 403px;
	width: 400px;
	height: auto;
	margin: 0 auto;				
	margin-bottom: 11px;				
	// background-color: @img-placeholder-grey;
	// display: inline-block;				
	// margin-bottom: 20px;
	// margin-right: 14px;
}
.grid-item-3--width2 { 
	width: 606px; 
}
.grid-item-3--width3 { 
	width: 815px; 
}
.grid-item-3--width4 { 
	width: 99%;
}


.grid-sizer-3 {
	width: 200px;
}
.gutter-sizer-3 {
	// width: 0.54%;
	width: 6px;
}
.grid-item-3 { 
	float: left;
	// display: inline-block;
	// width: 403px;
	width: 394px;
	height: auto;
	// margin: 0 auto;				
	margin-bottom: 11px;				
	// background-color: @img-placeholder-grey;
	// display: inline-block;				
	// margin-bottom: 20px;
	// margin-right: 14px;
	img {
		width: 100%;
	}
}
.grid-item-3--width2 { 
	width: 600px; 
}
.grid-item-3--width3 { 
	width: 806px; 
}
.grid-item-3--width4 { 
	width: 1218px;
}


<li><h6>Location</h6><p>Republic of Maldives</p></li>									
<li><h6>Client</h6><p>Xanadu Holdings Pvt Ltd</p></li>									
<li><h6>Scope</h6><p>Building Design, Interior Design, Landscape</p></li>
<li><h6>Type</h6><p>Hotel</p></li>
<li><h6>No. of Keys</h6><p>58 Guestrooms and Villas</p></li>