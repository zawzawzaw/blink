$(document).ready(function(){
	$('.img-slider').slick({
	    slidesToShow: 4,
	  	slidesToScroll: 1	  	
  	});
});