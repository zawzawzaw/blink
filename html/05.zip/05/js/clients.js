$(function(){
	// $('#menu-logo-wrapper').addClass('white-version');
});