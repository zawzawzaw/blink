$(document).ready(function(){
	$('.popup_tooltip').popover();
});